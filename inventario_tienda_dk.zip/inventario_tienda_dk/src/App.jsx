import Inventario from "./components/ui/Inventario";

function App() {
  return (
    <div className="p-4">
      <Inventario />
    </div>
  );
}

export default App;