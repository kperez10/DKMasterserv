import { useState } from "react";

const productosIniciales = [
  { id: 1, nombre: "Zapatilla Nike", codigo: "Z001", stock: 10, pedidos: 2, precio: 250, talla: "42", estado: "Primera", categoria: "Zapatillas" },
  { id: 2, nombre: "Cartera Cuero", codigo: "C002", stock: 5, pedidos: 1, precio: 180, talla: "Única", estado: "Segunda", categoria: "Carteras" },
];

export default function Inventario() {
  const [productos, setProductos] = useState(productosIniciales);
  const [nuevoProducto, setNuevoProducto] = useState({ nombre: "", codigo: "", stock: 0, pedidos: 0, precio: 0, talla: "", estado: "Primera", categoria: "" });

  const agregarProducto = () => {
    const id = productos.length + 1;
    setProductos([...productos, { ...nuevoProducto, id }]);
    setNuevoProducto({ nombre: "", codigo: "", stock: 0, pedidos: 0, precio: 0, talla: "", estado: "Primera", categoria: "" });
  };

  return (
    <div>
      <div className="grid grid-cols-2 gap-2 mb-4">
        <input placeholder="Nombre" value={nuevoProducto.nombre} onChange={(e) => setNuevoProducto({ ...nuevoProducto, nombre: e.target.value })} />
        <input placeholder="Código" value={nuevoProducto.codigo} onChange={(e) => setNuevoProducto({ ...nuevoProducto, codigo: e.target.value })} />
        <input placeholder="Stock" type="number" value={nuevoProducto.stock} onChange={(e) => setNuevoProducto({ ...nuevoProducto, stock: parseInt(e.target.value) })} />
        <input placeholder="Pedidos" type="number" value={nuevoProducto.pedidos} onChange={(e) => setNuevoProducto({ ...nuevoProducto, pedidos: parseInt(e.target.value) })} />
        <input placeholder="Precio" type="number" value={nuevoProducto.precio} onChange={(e) => setNuevoProducto({ ...nuevoProducto, precio: parseFloat(e.target.value) })} />
        <input placeholder="Talla" value={nuevoProducto.talla} onChange={(e) => setNuevoProducto({ ...nuevoProducto, talla: e.target.value })} />
        <input placeholder="Primera o Segunda" value={nuevoProducto.estado} onChange={(e) => setNuevoProducto({ ...nuevoProducto, estado: e.target.value })} />
        <input placeholder="Categoría" value={nuevoProducto.categoria} onChange={(e) => setNuevoProducto({ ...nuevoProducto, categoria: e.target.value })} />
        <button className="col-span-2 bg-blue-500 text-white py-1" onClick={agregarProducto}>Agregar producto</button>
      </div>

      <table className="w-full border">
        <thead>
          <tr>
            <th>Nombre</th><th>Código</th><th>Stock</th><th>Pedidos</th><th>Precio</th><th>Talla</th><th>Estado</th><th>Categoría</th>
          </tr>
        </thead>
        <tbody>
          {productos.map((producto) => (
            <tr key={producto.id}>
              <td>{producto.nombre}</td>
              <td>{producto.codigo}</td>
              <td>{producto.stock}</td>
              <td>{producto.pedidos}</td>
              <td>S/. {producto.precio}</td>
              <td>{producto.talla}</td>
              <td>{producto.estado}</td>
              <td>{producto.categoria}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}